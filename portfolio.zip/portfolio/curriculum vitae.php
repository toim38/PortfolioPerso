<?php
require_once "inc/init.inc.php";
require_once "inc/header.inc.php";
?>
<main class="container-fluid background-color">

<img src="photo/cv.jpg"  alt="">

</main>

    <!--introduction des form de bootstrap-->
    
<?php
    require_once "inc/footer.inc.php";
    ?>
</body>
</html>