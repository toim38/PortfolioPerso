<?php
require_once "inc/init.inc.php";
require_once "inc/header.inc.php";
?>

<div class="row" id="bgIndex">
  <section class="container mt-5">
    <img src="photo/entrée_orientale.jpg" alt="image de fond">
  </section>
</div>

<?php
  require_once "inc/footer.inc.php";
?>
