<?php
require_once "inc/init.inc.php";
require_once "inc/header.inc.php";
?>
<main class="container">
<div class="container mt-3">
  <img src="photo/entrée_orientale.jpg" alt="image de fond"   height="1500" weigth="3000" >
</div>
<div class="container mt-3">
  <?php
  require_once "inc/footer.inc.php";
  ?>
  </main>